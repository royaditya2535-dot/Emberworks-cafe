// Usage: npm run hash -- "your-chosen-password"
// Prints a bcrypt hash to paste into .env as ADMIN_PASSWORD_HASH.

const bcrypt = require('bcryptjs');

const password = process.argv[2];

if (!password) {
  console.error('Usage: npm run hash -- "your-chosen-password"');
  process.exit(1);
}

bcrypt.hash(password, 10).then((hash) => {
  console.log('\nPaste this into your .env file as ADMIN_PASSWORD_HASH:\n');
  console.log(hash);
  console.log('');
});
