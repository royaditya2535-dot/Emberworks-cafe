const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { requireAuth } = require('../middleware/auth');

const router = express.Router();

// Basic in-memory rate limiting per IP to slow down password guessing.
// Resets if the server restarts — fine for a small site, swap for a
// real rate-limiter (e.g. a Redis-backed one) at higher traffic.
const attempts = new Map();
const MAX_ATTEMPTS = 8;
const WINDOW_MS = 10 * 60 * 1000; // 10 minutes

function tooManyAttempts(ip) {
  const record = attempts.get(ip);
  if (!record) return false;
  if (Date.now() - record.first > WINDOW_MS) {
    attempts.delete(ip);
    return false;
  }
  return record.count >= MAX_ATTEMPTS;
}

function recordFailedAttempt(ip) {
  const record = attempts.get(ip);
  if (!record || Date.now() - record.first > WINDOW_MS) {
    attempts.set(ip, { count: 1, first: Date.now() });
  } else {
    record.count += 1;
  }
}

function clearAttempts(ip) {
  attempts.delete(ip);
}

router.post('/login', async (req, res) => {
  const ip = req.ip;
  const { username, password } = req.body || {};

  if (tooManyAttempts(ip)) {
    return res.status(429).json({ error: 'Too many attempts. Try again in a few minutes.' });
  }

  if (!username || !password) {
    return res.status(400).json({ error: 'Username and password are required.' });
  }

  const hash = process.env.ADMIN_PASSWORD_HASH;
  if (!hash || hash.startsWith('replace_')) {
    return res.status(500).json({
      error: 'Server is not configured yet — set ADMIN_PASSWORD_HASH in .env (see README).'
    });
  }

  const validUsername = username === process.env.ADMIN_USERNAME;
  const validPassword = await bcrypt.compare(password, hash);

  if (!validUsername || !validPassword) {
    recordFailedAttempt(ip);
    return res.status(401).json({ error: 'Incorrect username or password.' });
  }

  clearAttempts(ip);
  const token = jwt.sign({ username }, process.env.JWT_SECRET, { expiresIn: '8h' });
  res.json({ token, expiresIn: '8h' });
});

// Lets the frontend check on page load whether a saved token is still valid.
router.get('/verify', requireAuth, (req, res) => {
  res.json({ valid: true, username: req.admin.username });
});

module.exports = router;
