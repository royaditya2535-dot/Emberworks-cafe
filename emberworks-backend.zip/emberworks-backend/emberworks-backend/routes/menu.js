const express = require('express');
const crypto = require('crypto');
const { readMenu, writeMenu } = require('../db');
const { requireAuth } = require('../middleware/auth');

const router = express.Router();

function validatePrice(price) {
  return typeof price === 'number' && !Number.isNaN(price) && price >= 0;
}

// Public — anyone visiting the site can see the menu.
router.get('/', (req, res) => {
  res.json(readMenu());
});

// Everything below requires a valid admin token.
router.post('/', requireAuth, (req, res) => {
  const { name, desc, price } = req.body || {};
  if (!name || !validatePrice(price)) {
    return res.status(400).json({ error: 'A valid name and non-negative price are required.' });
  }
  const items = readMenu();
  const item = { id: crypto.randomUUID(), name: String(name).trim(), desc: String(desc || '').trim(), price };
  items.push(item);
  writeMenu(items);
  res.status(201).json(item);
});

router.put('/:id', requireAuth, (req, res) => {
  const items = readMenu();
  const item = items.find((i) => i.id === req.params.id);
  if (!item) return res.status(404).json({ error: 'Item not found.' });

  const { name, desc, price } = req.body || {};
  if (name !== undefined) {
    if (!String(name).trim()) return res.status(400).json({ error: 'Name cannot be empty.' });
    item.name = String(name).trim();
  }
  if (desc !== undefined) item.desc = String(desc).trim();
  if (price !== undefined) {
    if (!validatePrice(price)) return res.status(400).json({ error: 'Price must be a non-negative number.' });
    item.price = price;
  }

  writeMenu(items);
  res.json(item);
});

router.delete('/:id', requireAuth, (req, res) => {
  const items = readMenu();
  const exists = items.some((i) => i.id === req.params.id);
  if (!exists) return res.status(404).json({ error: 'Item not found.' });
  writeMenu(items.filter((i) => i.id !== req.params.id));
  res.status(204).send();
});

module.exports = router;
