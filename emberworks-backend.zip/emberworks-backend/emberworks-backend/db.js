const fs = require('fs');
const path = require('path');

const MENU_FILE = path.join(__dirname, 'data', 'menu.json');

// Tiny file-based "database". Good enough for a single-server demo or
// small site. For real production traffic, swap these two functions for
// calls to a real database (Postgres, SQLite, etc.) — every route in
// routes/menu.js only talks to readMenu()/writeMenu(), so that's the
// only file you'd need to change.

function readMenu() {
  if (!fs.existsSync(MENU_FILE)) return [];
  const raw = fs.readFileSync(MENU_FILE, 'utf-8');
  try {
    return JSON.parse(raw);
  } catch (err) {
    console.error('menu.json is corrupted, returning empty list:', err.message);
    return [];
  }
}

function writeMenu(items) {
  fs.writeFileSync(MENU_FILE, JSON.stringify(items, null, 2));
}

module.exports = { readMenu, writeMenu };
