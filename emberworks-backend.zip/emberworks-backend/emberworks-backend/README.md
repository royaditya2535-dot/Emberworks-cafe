# Emberworks Coffee Co. — with a real backend

This is the same site, now backed by an actual Node.js + Express server instead
of a client-side trick. The menu lives in a file on the server (`data/menu.json`),
and admin login is checked server-side with a hashed password and a signed
session token (JWT) — not a password sitting in the page's JavaScript.

## What changed from the front-end-only version

- **Real login**: the browser sends username/password to `POST /api/auth/login`.
  The server checks it against a bcrypt hash and returns a signed token. The
  password itself is never visible in the page source.
- **Real authorization**: every write to the menu (`POST`, `PUT`, `DELETE`)
  requires that token in an `Authorization: Bearer ...` header. The server
  rejects requests without a valid one — editing isn't just hidden in the UI,
  it's actually blocked.
- **Real persistence**: the menu is stored in `data/menu.json` on the server.
  It survives restarts and is the same for every visitor, the way a real
  site's menu would be.
- **Basic brute-force protection**: repeated failed logins from the same IP
  get rate-limited for a few minutes.

## 1. Install dependencies

You'll need [Node.js](https://nodejs.org) 18 or newer installed. Then, from
this folder:

```bash
npm install
```

## 2. Configure your admin login

Copy the example environment file:

```bash
cp .env.example .env
```

Generate a hash of the password you want to use:

```bash
npm run hash -- "your-chosen-password"
```

Copy the printed hash into `.env` as `ADMIN_PASSWORD_HASH`. Also set a random
`JWT_SECRET` — you can generate one with:

```bash
node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"
```

Your `.env` should end up looking like:

```
PORT=3000
JWT_SECRET=9f2a... (your random string)
ADMIN_USERNAME=admin
ADMIN_PASSWORD_HASH=$2a$10$... (your generated hash)
```

**Never commit `.env` to version control** — it holds your real secrets.
`.env.example` is the template that's safe to share.

## 3. Run it

```bash
npm start
```

Then open **http://localhost:3000**. Click "Admin" in the nav and sign in
with the username/password you set above.

For local development with auto-restart on file changes:

```bash
npm run dev
```

## How the pieces fit together

```
server.js          → starts Express, wires up routes, serves public/index.html
routes/auth.js      → POST /api/auth/login, GET /api/auth/verify
routes/menu.js      → GET/POST/PUT/DELETE /api/menu
middleware/auth.js  → checks the JWT on protected routes
db.js               → reads/writes data/menu.json
data/menu.json      → the actual menu data — back this up / put it under version control
public/index.html   → the site itself, calls the API with fetch()
```

## Moving this to a real, always-on deployment

Right now this runs on your machine. To put it on the internet:

1. Push this folder to a Git repo.
2. Deploy it to a Node-friendly host (Render, Railway, Fly.io, a VPS, etc.).
3. Set `JWT_SECRET`, `ADMIN_USERNAME`, and `ADMIN_PASSWORD_HASH` as environment
   variables in that host's dashboard — don't upload your `.env` file itself.
4. Serve the site over **HTTPS** (most hosts do this automatically) — without
   it, login credentials and tokens travel in plain text.

## A note on scale

`data/menu.json` is a flat file — perfect for a single small site, but it
isn't built for many simultaneous writers or large amounts of data. If you
outgrow it, swap the two functions in `db.js` for calls to a real database
(Postgres, MySQL, SQLite) — nothing else in the app needs to change, since
every route only talks to `readMenu()` / `writeMenu()`.
